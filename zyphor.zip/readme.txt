# Zyphor - Le Voyage Intérieur de l'Absurde

Bienvenue, voyageur perdu, dans **Zyphor**, une expérience qui transcende les limites de la logique et du temps. Ce n’est pas un jeu. C’est un reflet de l’âme humaine, égarée dans un océan de pixels et de formes inconnues.

## Instructions ? Peut-être.
1. **Lancez l’exécutable**, ou ne le faites pas. Peut-être que vous n'êtes pas prêt. Le fichier `Zyphor.exe` est là, mais est-ce vraiment ce que vous voulez ? Double-cliquez, ou ne le faites pas.
   
2. **Le contrôle de votre destin** : Utilisez les **flèches directionnelles** pour vous mouvoir dans cet espace sans fin. Ou ne les utilisez pas. Peut-être que le destin ne veut pas que vous bougiez. L’espace-temps ne se plie pas à vos volontés.

3. **Le sens du jeu ?** : Peut-être qu'il y en a un, ou peut-être que vous vous êtes simplement laissé piéger par un enchevêtrement de formes, de couleurs et de sons. Le but est simple. Ou pas. Peut-être que vous n'avez même pas besoin de but. Acceptez-le, ou refusez-le.

4. **Les événements mystérieux** : Chaque forme géométrique qui apparaît dans votre champ de vision n’a aucun sens. Ou peut-être que si. Un carré vert ? Un cercle rouge ? Une ligne noire ? Vous les voyez, vous les ignorez. Rien n'a de signification. Laissez vos yeux se perdre dans le chaos.

5. **Messages incompréhensibles** : Le texte qui s'affiche à l'écran n'est pas pour vous. Ou peut-être que si. Il se trouve là, comme une invitation, mais aussi comme une serrure sans clé. "LOREMM" ? Un mensonge ? Une vérité ? Il n'y a pas de réponse. La réponse est la question.

## Est-ce un jeu ?
Est-ce vraiment ce que vous appelez un jeu ? **Zyphor** se moque de vos attentes. Il ne respecte pas les règles. Il les défie. Chaque interaction avec le jeu est une interrogation sur la nature même de l'existence. Peut-être que le jeu se joue de vous, peut-être que vous jouez avec lui. Peut-être que tout cela est inutile. C’est vous qui choisissez.

## Installation :
1. **Extraire les fichiers** : Décompressez cette archive. Ou ne le faites pas. Le chemin du destin est imprévisible. Le fichier `Zyphor.exe` vous attend. Ou pas. Peut-être qu’il n’attend personne.

2. **Lancez l'exécutable**, mais seulement si vous en ressentez l'appel. Si vous y allez, sachez que rien n’en sortira comme prévu.

## Pourquoi jouer ?
Pourquoi pas ? Mais pourquoi faire quoi que ce soit ? Peut-être que vous allez découvrir des choses sur vous-même. Peut-être pas. **Zyphor** est un miroir déformant de vos attentes. Vous n’êtes pas ici pour « jouer ». Vous êtes ici pour **être**. Ou peut-être que non. Vous voyez, il n'y a pas de bonne réponse.

## Problèmes connus :
- **Le jeu ne répond pas à vos attentes.** C'est normal. Peut-être qu'il n'est pas censé répondre.
- **Les formes géométriques sont déroutantes.** Elles sont là pour vous montrer que la réalité n'est qu'un mensonge.
- **Les couleurs sont trop vives.** Ou peut-être pas assez. Tout dépend de votre perception.

## Compilé en .exe :
Nous avons pris soin de compiler le jeu en un exécutable. Mais est-ce que ce fichier est vraiment un exécutable, ou n'est-ce qu'une illusion de votre esprit ? Double-cliquez si vous osez. Mais n’oubliez pas, la machine est tout sauf honnête. 

## Crédits :
Ce jeu, si on peut vraiment l’appeler ainsi, est un produit de l'imagination débridée, une ode à l'absurde, une célébration de l'incompréhensible. Il a été créé pour vous aider à remettre en question votre propre existence. Ou peut-être pas.

### Pour finir :
Fermez les yeux. Respirez. **Zyphor** est là. Peut-être que vous êtes déjà en train de jouer. Ou peut-être que tout cela n'est qu'un rêve.

---
“**Zyphor** : La quête de l'inconnu dans l'univers infini de la confusion.”
