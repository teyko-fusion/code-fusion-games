==============================
    GRZHTOV - édition 𝓒𝓱𝓪𝓸𝓼
==============================

1. ☉ Introduction :
   Les formes savent. Les couleurs voient. Vous ? Peut-être.

2. ❓ Instructions :
   - Appuyez. Cliquez. Regardez. Ou ne faites rien.
   - Chaque instant est une décision, mais sans conséquence réelle.
   - Comprendre est un luxe, ici inutile.

3. ⌛ Minimum requis :
   - Une boîte à calculs (ordinateur ?) et des yeux. Parfois un écran aide.

4. 📜 Licences :
   Grzhtov est certifié sans licence, sauf les licences que vous avez déjà. 
   Utilisation à vos risques et périls imaginaires.

5. 🚀 Usage professionnel interdit :
   - Toute tentative d'explication sera sanctionnée par une ligne rouge.
   - Jouez uniquement si vous ne cherchez pas de sens.

6. 👁‍🗨 Conclusion :
   Le jeu joue-t-il avec vous, ou vous avec lui ? Peut-être les deux. 

==============================
GRZHTOV © Un auteur inconnu, 2025.
==============================
